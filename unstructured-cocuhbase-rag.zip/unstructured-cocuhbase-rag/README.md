# Personal Digital Library Assistant

Powered by [Unstructured](https://unstructured.io), [LangChain](https://www.langchain.com), 
[Couchbase](https://www.couchbase.com), [Ollama](https://ollama.com), [HuggingFace](https://huggingface.co),
and [Streamlit](https://streamlit.io).

